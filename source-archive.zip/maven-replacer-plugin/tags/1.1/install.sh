#!/bin/sh

mvn clean install
rm -fR target
rm some*
